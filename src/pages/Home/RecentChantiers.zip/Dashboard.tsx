// src/components/dashboard/index.js
// Main entry point that assembles all dashboard components

import React, { useEffect, useState } from 'react';
import { Container, Grid, Box, Typography, CircularProgress, useMediaQuery } from '@mui/material';
import { styled, useTheme } from '@mui/material/styles';

// Import dashboard components
import DashboardHeader from './DashboardHeader';
import StatCards from './StatCards';
import RecentChantiers from './RecentChantiers';
import PendingPdps from './PendingPdps';
import RiskOverview from './RiskOverview';
import NotificationsPanel from './NotificationsPanel';
import ActivityChart from './ActivityChart';
import WorkerDistribution from './WorkerDistribution';

// Styled container for the dashboard
const DashboardContainer = styled(Container)(({ theme }) => ({
  padding: theme.spacing(4),
  backgroundColor: theme.palette.mode === 'light' 
    ? theme.palette.grey[50] 
    : theme.palette.background.default,
  borderRadius: theme.shape.borderRadius * 2,
  minHeight: '90vh',
}));

const Dashboard = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const isTablet = useMediaQuery(theme.breakpoints.down('md'));
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [dashboardData, setDashboardData] = useState({
    stats: {
      activeChantiersCount: 5,
      pendingPdpsCount: 2,
      highRisksCount: 3,
      assignedWorkersCount: 12
    },
    recentChantiers: [
      { id: 1, nom: 'Chantier Alpha', operation: 'Opération Principale', dateFin: new Date(2025, 4, 1), status: 'Actif', progress: 75, location: 'Zone Nord', entrepriseExt: 'EE Externe A' },
      { id: 2, nom: 'Site Bêta', operation: 'Maintenance', dateFin: new Date(2025, 3, 15), status: 'En cours', progress: 45, location: 'Zone Sud', entrepriseExt: 'Autre EE B' },
      { id: 3, nom: 'Projet Gamma', operation: 'Nouvelle Construction', dateFin: new Date(2025, 8, 30), status: 'Planifié', progress: 10, location: 'Zone Est', entrepriseExt: 'EE Externe C' },
    ],
    pendingPdps: [
      { id: 101, chantier: 1, chantierNom: 'Chantier Alpha', entrepriseExterieure: 201, status: 'Signature Requise', entrepriseNom: 'EE Externe A', requestDate: new Date(2025, 3, 25) },
      { id: 102, chantier: 2, chantierNom: 'Site Bêta', entrepriseExterieure: 202, status: 'Validation Requise', entrepriseNom: 'Autre EE B', requestDate: new Date(2025, 3, 22) },
    ],
    keyRisks: [
      { id: 301, title: 'Travail en Hauteur', level: 'Élevé', chantier: 'Chantier Alpha', impacts: ['Chute', 'Blessure grave'], progress: 70 },
      { id: 302, title: 'Risque Électrique', level: 'Moyen', chantier: 'Site Bêta', impacts: ['Électrocution', 'Incendie'], progress: 50 },
      { id: 303, title: 'Espaces Confinés', level: 'Élevé', chantier: 'Chantier Alpha', impacts: ['Asphyxie', 'Intoxication'], progress: 30 },
    ],
    notifications: [
      { id: 401, type: 'inspection', message: 'Inspection requise pour Chantier Alpha', date: 'Demain', priority: 'high' },
      { id: 402, type: 'worker', message: 'Nouveau travailleur ajouté: J. Dupont', date: 'Aujourd\'hui', priority: 'medium' },
      { id: 403, type: 'risk', message: 'Nouveau risque identifié sur Site Bêta', date: 'Hier', priority: 'high' },
    ],
    activityData: [
      { month: 'Jan', chantiers: 4, pdps: 2, risques: 5 },
      { month: 'Fév', chantiers: 5, pdps: 3, risques: 4 },
      { month: 'Mar', chantiers: 3, pdps: 2, risques: 6 },
      { month: 'Avr', chantiers: 5, pdps: 4, risques: 3 },
      { month: 'Mai', chantiers: 6, pdps: 2, risques: 5 },
    ],
    workerDistribution: [
      { name: 'Site Alpha', workers: 5 },
      { name: 'Site Bêta', workers: 3 },
      { name: 'Site Gamma', workers: 4 },
    ]
  });

  useEffect(() => {
    // Here you would fetch your dashboard data from your API
    const fetchDashboardData = async () => {
      setLoading(true);
      try {
        // Replace with actual API calls
        // const response = await api.getDashboardData();
        // setDashboardData(response.data);
        
        // Simulate API delay
        setTimeout(() => {
          setLoading(false);
        }, 1000);
      } catch (err) {
        setError(err.message || 'Une erreur est survenue lors du chargement des données');
        setLoading(false);
      }
    };
    
    fetchDashboardData();
  }, []);

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="80vh">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
        <Typography color="error">Erreur de chargement: {error}</Typography>
      </Container>
    );
  }

  return (
    <DashboardContainer maxWidth="xl">
      <DashboardHeader />
      
      <Grid container spacing={3}>
        {/* Statistics Cards */}
        <Grid item xs={12}>
          <StatCards stats={dashboardData.stats} />
        </Grid>
        
        {/* Main Content - Left Column */}
        <Grid item xs={12} lg={8}>
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <RecentChantiers chantiers={dashboardData.recentChantiers} />
            </Grid>
            <Grid item xs={12}>
              <ActivityChart data={dashboardData.activityData} />
            </Grid>
          </Grid>
        </Grid>
        
        {/* Right Column - Sidebar */}
        <Grid item xs={12} lg={4}>
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <PendingPdps pdps={dashboardData.pendingPdps} />
            </Grid>
            <Grid item xs={12}>
              <RiskOverview risks={dashboardData.keyRisks} />
            </Grid>
            <Grid item xs={12}>
              <NotificationsPanel notifications={dashboardData.notifications} />
            </Grid>
            <Grid item xs={12}>
              <WorkerDistribution data={dashboardData.workerDistribution} />
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </DashboardContainer>
  );
};

export default Dashboard;