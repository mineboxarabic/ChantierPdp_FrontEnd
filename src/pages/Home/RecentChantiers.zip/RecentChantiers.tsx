// src/components/dashboard/RecentChantiers.jsx
import React, { useState } from 'react';
import { 
  Box, 
  Typography, 
  Divider, 
  Button, 
  IconButton,
  Avatar,
  LinearProgress,
  Tooltip,
  Chip,
  Menu,
  MenuItem,
  useMediaQuery
} from '@mui/material';
import { styled, useTheme, alpha } from '@mui/material/styles';
import {
  ChevronRight as ChevronRightIcon,
  MoreVert as MoreVertIcon,
  Construction as ConstructionIcon,
  CalendarMonth as CalendarIcon,
  LocationOn as LocationIcon,
  Business as BusinessIcon,
  Visibility as VisibilityIcon,
  Edit as EditIcon,
  Delete as DeleteIcon
} from '@mui/icons-material';

// Styled components
const CardWrapper = styled(Box)(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  borderRadius: theme.shape.borderRadius * 2,
  boxShadow: '0 2px 24px rgba(0,0,0,0.07)',
  padding: theme.spacing(3),
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
}));

const CardHeader = styled(Box)(({ theme }) => ({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: theme.spacing(2),
}));

const CardTitle = styled(Typography)(({ theme }) => ({
  fontWeight: 600,
  display: 'flex',
  alignItems: 'center',
  '& .MuiSvgIcon-root': {
    marginRight: theme.spacing(1),
    color: theme.palette.primary.main,
  },
}));

const ChantierItem = styled(Box)(({ theme }) => ({
  padding: theme.spacing(2),
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.background.default, 0.5),
  marginBottom: theme.spacing(2),
  '&:last-child': {
    marginBottom: 0,
  },
  transition: 'transform 0.2s, box-shadow 0.2s',
  '&:hover': {
    transform: 'translateY(-3px)',
    boxShadow: '0 6px 16px rgba(0,0,0,0.08)',
    backgroundColor: theme.palette.background.paper,
  },
}));

const StatusChip = styled(Chip)(({ theme, status }) => {
  const statusColors = {
    'Actif': {
      bg: alpha(theme.palette.success.main, 0.12),
      color: theme.palette.success.dark,
    },
    'En cours': {
      bg: alpha(theme.palette.info.main, 0.12),
      color: theme.palette.info.dark,
    },
    'Planifié': {
      bg: alpha(theme.palette.warning.main, 0.12),
      color: theme.palette.warning.dark,
    },
    'Terminé': {
      bg: alpha(theme.palette.grey[500], 0.12),
      color: theme.palette.text.secondary,
    },
  };

  const colorConfig = statusColors[status] || {
    bg: alpha(theme.palette.grey[500], 0.12),
    color: theme.palette.text.secondary,
  };

  return {
    backgroundColor: colorConfig.bg,
    color: colorConfig.color,
    fontWeight: 600,
    borderRadius: '16px',
    border: 'none',
  };
});

const InfoItem = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  marginBottom: theme.spacing(1),
  '& .MuiSvgIcon-root': {
    fontSize: '0.9rem',
    marginRight: theme.spacing(0.75),
    color: theme.palette.text.secondary,
  },
  '& .MuiTypography-root': {
    fontSize: '0.85rem',
    color: theme.palette.text.secondary,
  },
}));

const ProgressWrapper = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  marginTop: theme.spacing(1.5),
  '& .MuiLinearProgress-root': {
    height: 8,
    borderRadius: 4,
    backgroundColor: alpha(theme.palette.grey[500], 0.12),
    flexGrow: 1,
    marginRight: theme.spacing(1),
  },
}));

// Function to format date as DD/MM/YYYY
const formatDate = (date) => {
  return date instanceof Date 
    ? `${date.getDate().toString().padStart(2, '0')}/${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getFullYear()}`
    : 'Date non définie';
};

// Main Component
const RecentChantiers = ({ chantiers }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [menuAnchorEl, setMenuAnchorEl] = useState(null);
  const [selectedChantierId, setSelectedChantierId] = useState(null);
  
  const handleMenuClick = (event, chantierId) => {
    event.stopPropagation();
    setMenuAnchorEl(event.currentTarget);
    setSelectedChantierId(chantierId);
  };
  
  const handleMenuClose = () => {
    setMenuAnchorEl(null);
    setSelectedChantierId(null);
  };
  
  const getProgressColor = (progress) => {
    if (progress >= 75) return theme.palette.success.main;
    if (progress >= 40) return theme.palette.info.main;
    return theme.palette.warning.main;
  };

  return (
    <CardWrapper>
      <CardHeader>
        <CardTitle variant="h6" component="h2">
          <ConstructionIcon fontSize="small" />
          Chantiers Récents
        </CardTitle>
        <Button 
          size="small" 
          endIcon={<ChevronRightIcon />}
          sx={{ 
            textTransform: 'none', 
            fontWeight: 600,
            '&:hover': { backgroundColor: alpha(theme.palette.primary.main, 0.08) }
          }}
        >
          Voir Tout
        </Button>
      </CardHeader>
      <Divider sx={{ mb: 2 }} />
      
      <Box sx={{ flexGrow: 1, overflow: 'auto' }}>
        {chantiers.length > 0 ? (
          chantiers.map((chantier) => (
            <ChantierItem key={chantier.id}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                  <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                    {chantier.nom}
                  </Typography>
                  
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: isMobile ? 1 : 2 }}>
                    <InfoItem>
                      <BusinessIcon />
                      <Typography>{chantier.operation}</Typography>
                    </InfoItem>
                    
                    <InfoItem>
                      <CalendarIcon />
                      <Typography>Fin: {formatDate(chantier.dateFin)}</Typography>
                    </InfoItem>
                    
                    <InfoItem>
                      <LocationIcon />
                      <Typography>{chantier.location}</Typography>
                    </InfoItem>
                  </Box>
                  
                  <ProgressWrapper>
                    <LinearProgress 
                      variant="determinate" 
                      value={chantier.progress} 
                      sx={{ 
                        '& .MuiLinearProgress-bar': {
                          backgroundColor: getProgressColor(chantier.progress)
                        }
                      }}
                    />
                    <Typography variant="caption" fontWeight={600}>
                      {chantier.progress}%
                    </Typography>
                  </ProgressWrapper>
                </Box>
                
                <Box sx={{ display: 'flex', alignItems: 'center', ml: 2 }}>
                  <StatusChip label={chantier.status} size="small" status={chantier.status} />
                  <IconButton 
                    size="small" 
                    onClick={(e) => handleMenuClick(e, chantier.id)}
                    sx={{ ml: 1 }}
                  >
                    <MoreVertIcon fontSize="small" />
                  </IconButton>
                </Box>
              </Box>
            </ChantierItem>
          ))
        ) : (
          <Typography color="text.secondary" sx={{ p: 2, textAlign: 'center' }}>
            Aucun chantier récent trouvé
          </Typography>
        )}
      </Box>
      
      <Menu
        anchorEl={menuAnchorEl}
        open={Boolean(menuAnchorEl)}
        onClose={handleMenuClose}
      >
        <MenuItem onClick={handleMenuClose}>
          <VisibilityIcon fontSize="small" sx={{ mr: 1 }} />
          Afficher le détail
        </MenuItem>
        <MenuItem onClick={handleMenuClose}>
          <EditIcon fontSize="small" sx={{ mr: 1 }} />
          Modifier
        </MenuItem>
        <MenuItem onClick={handleMenuClose} sx={{ color: theme.palette.error.main }}>
          <DeleteIcon fontSize="small" sx={{ mr: 1 }} />
          Supprimer
        </MenuItem>
      </Menu>
    </CardWrapper>
  );
};

export default RecentChantiers;