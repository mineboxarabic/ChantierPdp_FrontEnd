// src/components/dashboard/StatCards.jsx
import React from 'react';
import { Grid, Box, Typography, Avatar, useMediaQuery } from '@mui/material';
import { styled, useTheme, alpha } from '@mui/material/styles';
import {
  Construction as ConstructionIcon,
  AssignmentLate as AssignmentLateIcon,
  WarningAmber as WarningAmberIcon,
  People as PeopleIcon,
  TrendingUp as TrendingUpIcon,
  TrendingDown as TrendingDownIcon
} from '@mui/icons-material';

// Styled component for the stat cards
const StatsCard = styled(Box)(({ theme, color = 'primary' }) => ({
  padding: theme.spacing(3),
  borderRadius: theme.shape.borderRadius * 2,
  backgroundColor: alpha(theme.palette[color].light, 0.12),
  display: 'flex',
  alignItems: 'center',
  position: 'relative',
  overflow: 'hidden',
  transition: 'transform 0.2s, box-shadow 0.2s',
  '&:hover': {
    transform: 'translateY(-4px)',
    boxShadow: `0 8px 24px -4px ${alpha(theme.palette[color].main, 0.15)}`,
  },
  '&::after': {
    content: '""',
    position: 'absolute',
    top: 0,
    right: 0,
    width: '30%',
    height: '100%',
    backgroundImage: `linear-gradient(to right, transparent, ${alpha(theme.palette[color].main, 0.05)})`,
    borderTopRightRadius: theme.shape.borderRadius * 2,
    borderBottomRightRadius: theme.shape.borderRadius * 2,
  }
}));

const IconWrapper = styled(Avatar)(({ theme, color = 'primary' }) => ({
  backgroundColor: alpha(theme.palette[color].main, 0.12),
  color: theme.palette[color].main,
  width: 56,
  height: 56,
  borderRadius: '18px',
  marginRight: theme.spacing(2.5),
}));

const StatContent = styled(Box)(({ theme }) => ({
  flex: 1,
}));

const TrendIcon = styled(Box)(({ theme, positive = true }) => ({
  display: 'flex',
  alignItems: 'center',
  color: positive ? theme.palette.success.main : theme.palette.error.main,
  marginLeft: theme.spacing(1),
}));

const StatCards = ({ stats }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  
  // Data for the cards
  const cardsData = [
    {
      title: 'Chantiers Actifs',
      value: stats.activeChantiersCount,
      icon: <ConstructionIcon />,
      color: 'primary',
      trend: '+12% ce mois',
      trendPositive: true
    },
    {
      title: 'PDPs en Attente',
      value: stats.pendingPdpsCount,
      icon: <AssignmentLateIcon />,
      color: 'warning',
      trend: '-3% ce mois',
      trendPositive: true
    },
    {
      title: 'Risques Élevés',
      value: stats.highRisksCount,
      icon: <WarningAmberIcon />,
      color: 'error',
      trend: '+2% ce mois',
      trendPositive: false
    },
    {
      title: 'Travailleurs Assignés',
      value: stats.assignedWorkersCount,
      icon: <PeopleIcon />,
      color: 'success',
      trend: '+8% ce mois',
      trendPositive: true
    }
  ];

  return (
    <Grid container spacing={3}>
      {cardsData.map((card, index) => (
        <Grid item xs={12} sm={6} md={3} key={index}>
          <StatsCard color={card.color}>
            <IconWrapper color={card.color}>
              {card.icon}
            </IconWrapper>
            
            <StatContent>
              <Typography variant="body2" color="text.secondary" fontWeight={500}>
                {card.title}
              </Typography>
              
              <Box sx={{ display: 'flex', alignItems: 'flex-end', mt: 0.5 }}>
                <Typography variant="h4" component="div" fontWeight={700}>
                  {card.value}
                </Typography>
                
                {!isMobile && (
                  <TrendIcon positive={card.trendPositive}>
                    {card.trendPositive ? <TrendingUpIcon fontSize="small" /> : <TrendingDownIcon fontSize="small" />}
                    <Typography variant="caption" fontWeight={600} sx={{ ml: 0.5 }}>
                      {card.trend}
                    </Typography>
                  </TrendIcon>
                )}
              </Box>
            </StatContent>
          </StatsCard>
        </Grid>
      ))}
    </Grid>
  );
};

export default StatCards;