// src/components/dashboard/RiskOverview.jsx
import React from 'react';
import { 
  Box, 
  Typography, 
  Divider, 
  Button, 
  IconButton,
  Avatar,
  LinearProgress,
  Chip,
  Tooltip
} from '@mui/material';
import { styled, useTheme, alpha } from '@mui/material/styles';
import {
  WarningAmber as WarningAmberIcon,
  ChevronRight as ChevronRightIcon,
  Construction as ConstructionIcon,
} from '@mui/icons-material';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip } from 'recharts';

// Styled components
const CardWrapper = styled(Box)(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  borderRadius: theme.shape.borderRadius * 2,
  boxShadow: '0 2px 24px rgba(0,0,0,0.07)',
  padding: theme.spacing(3),
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
}));

const CardHeader = styled(Box)(({ theme }) => ({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: theme.spacing(2),
}));

const CardTitle = styled(Typography)(({ theme }) => ({
  fontWeight: 600,
  display: 'flex',
  alignItems: 'center',
  '& .MuiSvgIcon-root': {
    marginRight: theme.spacing(1),
    color: theme.palette.error.main,
  },
}));

const RiskItem = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'flex-start',
  padding: theme.spacing(1.5),
  marginBottom: theme.spacing(1.5),
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.background.default, 0.5),
  transition: 'transform 0.2s, box-shadow 0.2s',
  '&:hover': {
    transform: 'translateY(-3px)',
    boxShadow: '0 6px 16px rgba(0,0,0,0.08)',
    backgroundColor: theme.palette.background.paper,
  },
  '&:last-child': {
    marginBottom: 0,
  }
}));

const StatusAvatar = styled(Avatar)(({ theme, level }) => {
  const colors = {
    'Élevé': theme.palette.error.main,
    'Moyen': theme.palette.warning.main,
    'Faible': theme.palette.success.main,
  };
  
  const bgColor = colors[level] || theme.palette.grey[500];
  
  return {
    backgroundColor: alpha(bgColor, 0.12),
    color: bgColor,
    width: 40,
    height: 40,
    marginRight: theme.spacing(2),
  };
});

const StatusChip = styled(Chip)(({ theme, level }) => {
  const colors = {
    'Élevé': {
      bg: alpha(theme.palette.error.main, 0.12),
      color: theme.palette.error.dark,
    },
    'Moyen': {
      bg: alpha(theme.palette.warning.main, 0.12),
      color: theme.palette.warning.dark,
    },
    'Faible': {
      bg: alpha(theme.palette.success.main, 0.12),
      color: theme.palette.success.dark,
    },
  };

  const colorConfig = colors[level] || {
    bg: alpha(theme.palette.grey[500], 0.12),
    color: theme.palette.text.secondary,
  };

  return {
    backgroundColor: colorConfig.bg,
    color: colorConfig.color,
    fontWeight: 600,
    borderRadius: '16px',
    border: 'none',
    height: 24,
    '& .MuiChip-label': {
      padding: '0 8px',
    }
  };
});

const ProgressWrapper = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  marginTop: theme.spacing(1),
  '& .MuiLinearProgress-root': {
    height: 6,
    borderRadius: 3,
    backgroundColor: alpha(theme.palette.grey[500], 0.12),
    flexGrow: 1,
    marginRight: theme.spacing(1),
  },
}));

// Sample data for the chart
const riskDistributionData = [
  { name: 'Élevé', value: 3, color: '#f44336' },
  { name: 'Moyen', value: 5, color: '#ff9800' },
  { name: 'Faible', value: 8, color: '#4caf50' },
];

// Main Component
const RiskOverview = ({ risks }) => {
  const theme = useTheme();
  
  // Helper to get progress color
  const getProgressColor = (level) => {
    switch (level) {
      case 'Élevé': return theme.palette.error.main;
      case 'Moyen': return theme.palette.warning.main;
      case 'Faible': return theme.palette.success.main;
      default: return theme.palette.grey[500];
    }
  };
  
  // Custom tooltip for the chart
  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      return (
        <Box sx={{ 
          backgroundColor: 'background.paper', 
          p: 1.5, 
          boxShadow: 3, 
          borderRadius: 1 
        }}>
          <Typography variant="body2" fontWeight={600}>
            {payload[0].name}: {payload[0].value}
          </Typography>
        </Box>
      );
    }
    return null;
  };

  return (
    <CardWrapper>
      <CardHeader>
        <CardTitle variant="h6" component="h2">
          <WarningAmberIcon fontSize="small" />
          Aperçu des Risques
        </CardTitle>
        <Button 
          size="small" 
          endIcon={<ChevronRightIcon />}
          sx={{ 
            textTransform: 'none', 
            fontWeight: 600,
            '&:hover': { backgroundColor: alpha(theme.palette.primary.main, 0.08) }
          }}
        >
          Voir Tout
        </Button>
      </CardHeader>
      <Divider sx={{ mb: 2 }} />
      
      {/* Chart section */}
      <Box sx={{ height: 160, mb: 2 }}>
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={riskDistributionData}
              cx="50%"
              cy="50%"
              innerRadius={50}
              outerRadius={70}
              paddingAngle={2}
              dataKey="value"
            >
              {riskDistributionData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <RechartsTooltip content={<CustomTooltip />} />
          </PieChart>
        </ResponsiveContainer>
      </Box>
      
      <Box sx={{ mb: 2 }}>
        <Typography variant="subtitle2" fontWeight={600} gutterBottom>
          Risques Principaux
        </Typography>
      </Box>
      
      {/* Risk list */}
      <Box sx={{ flexGrow: 1, overflow: 'auto' }}>
        {risks.length > 0 ? (
          risks.map((risk) => (
            <RiskItem key={risk.id}>
              <StatusAvatar level={risk.level}>
                <WarningAmberIcon fontSize="small" />
              </StatusAvatar>
              
              <Box sx={{ flexGrow: 1 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <Typography variant="subtitle2" fontWeight={600}>
                    {risk.title}
                  </Typography>
                  <StatusChip label={risk.level} size="small" level={risk.level} />
                </Box>
                
                <Box sx={{ display: 'flex', alignItems: 'center', mt: 0.5 }}>
                  <ConstructionIcon sx={{ fontSize: '0.9rem', mr: 0.5, color: 'text.secondary' }} />
                  <Typography variant="body2" color="text.secondary">
                    {risk.chantier}
                  </Typography>
                </Box>
                
                <ProgressWrapper>
                  <LinearProgress 
                    variant="determinate" 
                    value={risk.progress} 
                    sx={{ 
                      '& .MuiLinearProgress-bar': {
                        backgroundColor: getProgressColor(risk.level)
                      }
                    }}
                  />
                  <Typography variant="caption" fontWeight={600}>
                    {risk.progress}%
                  </Typography>
                </ProgressWrapper>
              </Box>
            </RiskItem>
          ))
        ) : (
          <Typography color="text.secondary" sx={{ p: 2, textAlign: 'center' }}>
            Aucun risque majeur identifié
          </Typography>
        )}
      </Box>
    </CardWrapper>
  );
};

export default RiskOverview;