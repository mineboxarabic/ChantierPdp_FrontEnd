// src/components/dashboard/PendingPdps.jsx
import React from 'react';
import { 
  Box, 
  Typography, 
  Divider, 
  Button, 
  IconButton,
  Avatar,
  Tooltip
} from '@mui/material';
import { styled, useTheme, alpha } from '@mui/material/styles';
import {
  AssignmentLate as AssignmentLateIcon,
  ChevronRight as ChevronRightIcon,
  BusinessCenter as BusinessIcon,
  CalendarToday as CalendarIcon,
  Receipt as ReceiptIcon
} from '@mui/icons-material';

// Styled components
const CardWrapper = styled(Box)(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  borderRadius: theme.shape.borderRadius * 2,
  boxShadow: '0 2px 24px rgba(0,0,0,0.07)',
  padding: theme.spacing(3),
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
}));

const CardHeader = styled(Box)(({ theme }) => ({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: theme.spacing(2),
}));

const CardTitle = styled(Typography)(({ theme }) => ({
  fontWeight: 600,
  display: 'flex',
  alignItems: 'center',
  '& .MuiSvgIcon-root': {
    marginRight: theme.spacing(1),
    color: theme.palette.warning.main,
  },
}));

const PdpItem = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  padding: theme.spacing(1.5),
  marginBottom: theme.spacing(1.5),
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.background.default, 0.5),
  transition: 'transform 0.2s, box-shadow 0.2s',
  '&:hover': {
    transform: 'translateY(-3px)',
    boxShadow: '0 6px 16px rgba(0,0,0,0.08)',
    backgroundColor: theme.palette.background.paper,
  },
  '&:last-child': {
    marginBottom: 0,
  }
}));

const StatusAvatar = styled(Avatar)(({ theme, status }) => {
  const isSignature = status === 'Signature Requise';
  return {
    backgroundColor: isSignature 
      ? alpha(theme.palette.warning.main, 0.12)
      : alpha(theme.palette.error.main, 0.12),
    color: isSignature 
      ? theme.palette.warning.main
      : theme.palette.error.main,
    width: 40,
    height: 40,
    marginRight: theme.spacing(2),
  };
});

const ActionButton = styled(Button)(({ theme }) => ({
  borderRadius: theme.shape.borderRadius * 5,
  textTransform: 'none',
  fontWeight: 600,
  minWidth: 'auto',
  padding: theme.spacing(0.5, 2),
  boxShadow: 'none',
  '&:hover': {
    boxShadow: '0 4px 8px rgba(0,0,0,0.15)',
  }
}));

const InfoText = styled(Typography)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  color: theme.palette.text.secondary,
  fontSize: '0.75rem',
  marginTop: theme.spacing(0.5),
  '& .MuiSvgIcon-root': {
    fontSize: '0.9rem',
    marginRight: theme.spacing(0.5),
  }
}));

// Function to format date as DD/MM/YYYY
const formatDate = (date) => {
  return date instanceof Date 
    ? `${date.getDate().toString().padStart(2, '0')}/${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getFullYear()}`
    : 'Date non définie';
};

// Calculate time since the request
const getTimeAgo = (date) => {
  if (!(date instanceof Date)) return '';
  
  const now = new Date();
  const diffInDays = Math.floor((now - date) / (1000 * 60 * 60 * 24));
  
  if (diffInDays === 0) return 'Aujourd\'hui';
  if (diffInDays === 1) return 'Hier';
  if (diffInDays < 7) return `Il y a ${diffInDays} jours`;
  if (diffInDays < 30) return `Il y a ${Math.floor(diffInDays / 7)} semaines`;
  return `Il y a ${Math.floor(diffInDays / 30)} mois`;
};

// Main Component
const PendingPdps = ({ pdps }) => {
  const theme = useTheme();
  
  return (
    <CardWrapper>
      <CardHeader>
        <CardTitle variant="h6" component="h2">
          <AssignmentLateIcon fontSize="small" />
          PDPs en Attente
        </CardTitle>
        <Button 
          size="small" 
          endIcon={<ChevronRightIcon />}
          sx={{ 
            textTransform: 'none', 
            fontWeight: 600,
            '&:hover': { backgroundColor: alpha(theme.palette.primary.main, 0.08) }
          }}
        >
          Voir Tout
        </Button>
      </CardHeader>
      <Divider sx={{ mb: 2 }} />
      
      <Box sx={{ flexGrow: 1, overflow: 'auto' }}>
        {pdps.length > 0 ? (
          pdps.map((pdp) => (
            <PdpItem key={pdp.id}>
              <StatusAvatar status={pdp.status}>
                <AssignmentLateIcon fontSize="small" />
              </StatusAvatar>
              
              <Box sx={{ flexGrow: 1 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <Box>
                    <Typography variant="subtitle2" fontWeight={600}>
                      {pdp.chantierNom}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {pdp.entrepriseNom}
                    </Typography>
                    <Box sx={{ display: 'flex', gap: 2, mt: 0.5 }}>
                      <InfoText>
                        <BusinessIcon /> {pdp.status}
                      </InfoText>
                      <InfoText>
                        <CalendarIcon /> {getTimeAgo(pdp.requestDate)}
                      </InfoText>
                    </Box>
                  </Box>
                  
                  <Tooltip title="Prendre action">
                    <ActionButton 
                      variant="contained" 
                      color={pdp.status === 'Signature Requise' ? 'warning' : 'primary'}
                      size="small"
                    >
                      Action
                    </ActionButton>
                  </Tooltip>
                </Box>
              </Box>
            </PdpItem>
          ))
        ) : (
          <Typography color="text.secondary" sx={{ p: 2, textAlign: 'center' }}>
            Aucun PDP en attente
          </Typography>
        )}
      </Box>
    </CardWrapper>
  );
};

export default PendingPdps;