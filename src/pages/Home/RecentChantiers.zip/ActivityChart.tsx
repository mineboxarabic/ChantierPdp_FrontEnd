// src/components/dashboard/ActivityChart.jsx
import React, { useState } from 'react';
import { 
  Box, 
  Typography, 
  Divider, 
  ToggleButtonGroup,
  ToggleButton,
  useMediaQuery
} from '@mui/material';
import { styled, useTheme, alpha } from '@mui/material/styles';
import {
  BarChart as BarChartIcon,
  Timeline as TimelineIcon,
  DonutLarge as DonutIcon
} from '@mui/icons-material';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';

// Styled components
const CardWrapper = styled(Box)(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  borderRadius: theme.shape.borderRadius * 2,
  boxShadow: '0 2px 24px rgba(0,0,0,0.07)',
  padding: theme.spacing(3),
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
}));

const CardHeader = styled(Box)(({ theme }) => ({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: theme.spacing(2),
}));

const CardTitle = styled(Typography)(({ theme }) => ({
  fontWeight: 600,
}));

const StyledToggleButtonGroup = styled(ToggleButtonGroup)(({ theme }) => ({
  backgroundColor: alpha(theme.palette.primary.light, 0.08),
  borderRadius: theme.shape.borderRadius * 5,
  '& .MuiToggleButtonGroup-grouped': {
    border: 0,
    borderRadius: theme.shape.borderRadius * 5,
    margin: 2,
    padding: theme.spacing(0.5, 1.5),
    textTransform: 'none',
    fontWeight: 500,
    fontSize: '0.8rem',
    '&.Mui-selected': {
      backgroundColor: theme.palette.primary.main,
      color: theme.palette.primary.contrastText,
      '&:hover': {
        backgroundColor: theme.palette.primary.dark,
      }
    },
    '&:not(:first-of-type)': {
      borderRadius: theme.shape.borderRadius * 5,
    },
    '&:first-of-type': {
      borderRadius: theme.shape.borderRadius * 5,
    },
  },
}));

// Custom tooltip for the chart
const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <Box
        sx={{
          backgroundColor: 'background.paper',
          p: 1.5,
          boxShadow: 3,
          borderRadius: 1,
        }}
      >
        <Typography variant="subtitle2" fontWeight={600} mb={0.5}>
          {label}
        </Typography>
        {payload.map((entry, index) => (
          <Box key={`item-${index}`} sx={{ display: 'flex', alignItems: 'center', mb: 0.5 }}>
            <Box
              component="span"
              sx={{
                width: 12,
                height: 12,
                borderRadius: '50%',
                backgroundColor: entry.color,
                mr: 1,
              }}
            />
            <Typography variant="caption" sx={{ color: 'text.secondary' }}>
              {entry.name}: <Box component="span" sx={{ fontWeight: 600, color: 'text.primary' }}>{entry.value}</Box>
            </Typography>
          </Box>
        ))}
      </Box>
    );
  }
  return null;
};

// Main Component
const ActivityChart = ({ data }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [chartType, setChartType] = useState('line');
  
  const handleChartTypeChange = (event, newType) => {
    if (newType !== null) {
      setChartType(newType);
    }
  };
  
  // Chart color scheme
  const chartColors = {
    chantiers: theme.palette.primary.main,
    pdps: theme.palette.warning.main,
    risques: theme.palette.error.main,
  };

  return (
    <CardWrapper>
      <CardHeader>
        <CardTitle variant="h6" component="h2">
          Activité Récente
        </CardTitle>
        <StyledToggleButtonGroup
          value={chartType}
          exclusive
          onChange={handleChartTypeChange}
          aria-label="chart type"
          size="small"
        >
          <ToggleButton value="line" aria-label="line chart">
            <TimelineIcon fontSize="small" />
          </ToggleButton>
          <ToggleButton value="bar" aria-label="bar chart">
            <BarChartIcon fontSize="small" />
          </ToggleButton>
        </StyledToggleButtonGroup>
      </CardHeader>
      <Divider sx={{ mb: 2 }} />
      
      <Box sx={{ flexGrow: 1, height: 300 }}>
        <ResponsiveContainer width="100%" height="100%">
          {chartType === 'line' ? (
            <LineChart
              data={data}
              margin={{ top: 5, right: 30, left: 0, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke={alpha(theme.palette.divider, 0.5)} />
              <XAxis 
                dataKey="month" 
                tick={{ fill: theme.palette.text.secondary, fontSize: 12 }}
                axisLine={{ stroke: theme.palette.divider }} 
              />
              <YAxis 
                tick={{ fill: theme.palette.text.secondary, fontSize: 12 }}
                axisLine={{ stroke: theme.palette.divider }}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend 
                wrapperStyle={{ 
                  paddingTop: 20,
                  fontSize: 12
                }}
                formatter={(value) => (
                  <span style={{ color: theme.palette.text.primary, fontWeight: 500 }}>
                    {value === 'chantiers' ? 'Chantiers' : 
                     value === 'pdps' ? 'PDPs' : 
                     value === 'risques' ? 'Risques' : value}
                  </span>
                )}
              />
              <Line
                type="monotone"
                dataKey="chantiers"
                stroke={chartColors.chantiers}
                strokeWidth={2}
                dot={{ r: 4, stroke: chartColors.chantiers, strokeWidth: 2, fill: theme.palette.background.paper }}
                activeDot={{ r: 6, stroke: theme.palette.background.paper, strokeWidth: 2, fill: chartColors.chantiers }}
              />
              <Line
                type="monotone"
                dataKey="pdps"
                stroke={chartColors.pdps}
                strokeWidth={2}
                dot={{ r: 4, stroke: chartColors.pdps, strokeWidth: 2, fill: theme.palette.background.paper }}
                activeDot={{ r: 6, stroke: theme.palette.background.paper, strokeWidth: 2, fill: chartColors.pdps }}
              />
              <Line
                type="monotone"
                dataKey="risques"
                stroke={chartColors.risques}
                strokeWidth={2}
                dot={{ r: 4, stroke: chartColors.risques, strokeWidth: 2, fill: theme.palette.background.paper }}
                activeDot={{ r: 6, stroke: theme.palette.background.paper, strokeWidth: 2, fill: chartColors.risques }}
              />
            </LineChart>
          ) : (
            <BarChart
              data={data}
              margin={{ top: 5, right: 30, left: 0, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke={alpha(theme.palette.divider, 0.5)} />
              <XAxis 
                dataKey="month" 
                tick={{ fill: theme.palette.text.secondary, fontSize: 12 }}
                axisLine={{ stroke: theme.palette.divider }} 
              />
              <YAxis 
                tick={{ fill: theme.palette.text.secondary, fontSize: 12 }}
                axisLine={{ stroke: theme.palette.divider }}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend 
                wrapperStyle={{ 
                  paddingTop: 20,
                  fontSize: 12
                }}
                formatter={(value) => (
                  <span style={{ color: theme.palette.text.primary, fontWeight: 500 }}>
                    {value === 'chantiers' ? 'Chantiers' : 
                     value === 'pdps' ? 'PDPs' : 
                     value === 'risques' ? 'Risques' : value}
                  </span>
                )}
              />
              <Bar 
                dataKey="chantiers" 
                fill={chartColors.chantiers} 
                radius={[4, 4, 0, 0]}
                name="Chantiers"
              />
              <Bar 
                dataKey="pdps" 
                fill={chartColors.pdps} 
                radius={[4, 4, 0, 0]}
                name="PDPs"
              />
              <Bar 
                dataKey="risques" 
                fill={chartColors.risques} 
                radius={[4, 4, 0, 0]}
                name="Risques"
              />
            </BarChart>
          )}
        </ResponsiveContainer>
      </Box>
    </CardWrapper>
  );
};

export default ActivityChart;